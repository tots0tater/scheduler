Requirements for this application:
- An Internet connection
- A Google account to access Google Calendar
- Python 3 or above
- The tkinter module
- The Google Calendar API
	> pip install --upgrade google-api-python-client
	> pip install tzlocal
